# Magic8Ball
A magic 8 Ball C# Console app
